select * from consulta;

